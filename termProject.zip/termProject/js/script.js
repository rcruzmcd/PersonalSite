

$(document).ready(function () {
    var brandTag = 'oldguyrunningtimefighter';
    var accessToken = '177494268.ccd0e5e.0d0c87a334d448d29bfd2abced5ed48b';
    var call = $.ajax({
        url: 'https://api.instagram.com/v1/users/self/media/recent/?access_token=' + accessToken + '&count=21',
        dataType: 'jsonp'
    }).done(function (data) {

        var images = data.data;
        //console.log(images);
        $(images).each(function () {
            //console.log(this);

            var caption = this.caption.text;
            var thumbURL = this.images.thumbnail.url;
            var stdURL = this.images.standard_resolution.url;
            var divImg = '<div class="oneImage"> <img width="300px" src=' + stdURL + '/> <span> ' + caption + ' </span> </div>';

            $('#galleryDiv').append(divImg);
        });

    });


});
